## Use Docker Create [kafka + elk]

#### Docker Image Pull

```shell
docker pull wurstmeister/kafka
docker pull wurstmeister/zookeeper
docker pull docker.elastic.co/elasticsearch/elasticsearch:6.4.3 
docker pull docker.elastic.co/logstash/logstash:6.4.3
docker pull docker.elastic.co/kibana/kibana:6.4.3
```



#### Start Step

1. start zookeeper
2. start kafka
3. start elasticsearch
4. start logstash
5. start kibana



#### Docker Run

```shell
## zookeeper
docker run -d --name zookeeper -p 2181:2181 -t wurstmeister/zookeeper

## kafka
docker run -d --name kafka -p 9092:9092 -e KAFKA_BROKER_ID=0 -e KAFKA_ZOOKEEPER_CONNECT=192.168.109.130:2181 -e KAFKA_ADVERTISED_LISTENERS=PLAINTEXT://192.168.109.130:9092 -e KAFKA_LISTENERS=PLAINTEXT://0.0.0.0:9092 --volume /etc/localtime:/etc/localtime -t wurstmeister/kafka

## elasticsearch
docker run -d --name elasticsearch -it -p 9200:9200 -p 9300:9300 -v "$PWD"/config/elasticsearch.yml:/usr/share/elasticsearch/config/elasticsearch.yml --ulimit nofile=65536:131072 docker.elastic.co/elasticsearch/elasticsearch:6.4.3

## kibana
docker run -it -d --name kibana -p 5601:5601 -v "$PWD"/config/kibana.yml:/usr/share/kibana/config/kibana.yml docker.elastic.co/kibana/kibana:6.4.3

## logstash
docker run -d --name logstash -it -v "$PWD"/pipeline/:/usr/share/logstash/pipeline/ -v "$PWD"/config/:/usr/share/logstash/config/ docker.elastic.co/logstash/logstash:6.4.3

```



#### ELK Properties

- elasticsearch

```shell
cd $elastsearch_dir
mkdir config
cd config
touch elasticsearch.yml
vim elasticsearch.yml

​```
xpack:
  ml.enabled: false
  monitoring.enabled: false
  security.enabled: false
  watcher.enabled: false
​```
```

- kibana

```shell
cd $kibana_dir
mkdir config
cd config
touch kibana.yml
vim kibana.yml

​```
server.host: "0.0.0.0"
elasticsearch.url: http://{宿主机IP}:9200
xpack:
  apm.ui.enabled: false
  graph.enabled: false
  ml.enabled: false
  monitoring.enabled: false
  reporting.enabled: false
  security.enabled: false
  grokdebugger.enabled: false
  searchprofiler.enabled: false
​```
```

- logstash

```shell
cd $logstash_dir
mkdir -p config pipeline pipeline/log
touch config/log4j2.properties
vim config/log4j2.properties

​```
logger.elasticsearchoutput.name = logstash.outputs.elasticsearch
logger.elasticsearchoutput.level = debug
​```

touch config/logstash.yml
vim config/logstash.yml

​```
config:
  reload:
    automatic: true
    interval: 3s
xpack:
  management.enabled: false
  monitoring.enabled: false
​```

touch config/pipelines.yml
vim config/pipelines.yml

​```
- pipeline.id: test
  path.config: /usr/share/logstash/pipeline/logstash-test.conf
  pipeline.workers: 3
​```

touch logstash-test.conf
vim logstash-test.conf

​```
input {
        kafka {
                #topic => "topic-test,test"     # 直接指定topic
                topics_pattern => "topic-.*"    # 使用正则匹配topic
                bootstrap_servers => "{宿主机IP}:9092" # IP和端口保持与kafka配置一致
                consumer_threads => 5
                decorate_events => true
        }
}
filter {
        mutate { gsub => [ "message", "\n\s*", "" ] } # 过滤掉换行符合后面携带的空格
}
output {
  elasticsearch {
        action => "index"  #The operation on ES
        hosts  => "{宿主机IP}:9200" #IP和端口保持与ElasticSearch一致, can be array.
        index  => "kafka-logs-%{+YYYY-MM-dd}"  #The index to write data to.
  }
  stdout {
        codec => rubydebug  # 将日志输出到当前的终端上显示
  }
}
​```
```

