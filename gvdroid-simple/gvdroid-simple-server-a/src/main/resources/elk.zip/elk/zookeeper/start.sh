docker run -d --name zookeeper -p 2181:2181 -v /etc/localtime:/etc/localtime --restart=always wurstmeister/zookeeper
