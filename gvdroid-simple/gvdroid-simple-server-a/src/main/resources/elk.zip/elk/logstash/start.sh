docker run -d --name logstash -it -v "$PWD"/pipeline/:/usr/share/logstash/pipeline/ -v "$PWD"/config/:/usr/share/logstash/config/ docker.elastic.co/logstash/logstash:6.4.3

